package com.example.pictureperfect;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.List;

public class ColorThreadMulti extends Thread implements Runnable{

    Bitmap img;
    int fromX;
    int toX;
    int fromY;
    int toY;
    List<ColorCode> colors;
    Manager m;
    int id;

    public ColorThreadMulti(Bitmap bmp, int fromX, int toX, int fromY, int toY, List<ColorCode> colors, Manager m, int id)
    {
        img = bmp;
        this.m = m;
        this.id = id;
        this.colors = colors;
        this.fromX = fromX;
        this.toX = toX;
        this.fromY = fromY;
        this.toY = toY;
    }


    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    public void run() {
        try {
            Thread.sleep(100);
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (int y = fromY; y < toY; y++)
        {
            for (int x = fromX; x < toX; x++)
            {
                int distance = 10000;
                int ind =0;
                int xDis = 0;
                Color clr = img.getColor(x,y);
                float r=0;
                float g=0;
                float b=0;
                r = 255*clr.getComponent(1);
                g = 255*clr.getComponent(2);
                b = 255*clr.getComponent(3);

                for (int c = 0; c < colors.size(); c++)
                {
                    int[] check = colors.get(c).cCode;
                    xDis += check[0]-r;
                    xDis += check[1]-g;
                    xDis += check[2]-b;
                    if (xDis < 0)
                    {
                        xDis = xDis * -1;
                    }
                    if (xDis < distance)
                    {
                        distance = xDis;
                        ind = c;
                    }
                }
                colors.get(ind).count ++;
            }
        }
        m.threadCompletion(this);
    }
}
