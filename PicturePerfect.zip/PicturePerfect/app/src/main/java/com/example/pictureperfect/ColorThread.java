package com.example.pictureperfect;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorSpace;
import android.os.Build;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.List;

public class ColorThread implements Runnable{

    Bitmap img;
    MainActivity ma;

    public ColorThread(Bitmap bmp, MainActivity mainActivity)
    {
        img = bmp;
        ma = mainActivity;
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    public void run() {
        int[] xy = new int[]{img.getWidth(),img.getHeight()};

        // Colors rgb
        int[] Black = new int[]{0,0,0};
        int black = 0;
        int[] VLR = new int[]{255,102,102};
        int verylightred = 0;
        int[] LR = new int[]{255,51,51};
        int lightred = 0;
        int[] Red = new int[]{255,0,0};
        int red = 0;
        int[] DR = new int[]{204,0,0};
        int darkred = 0;
        int[] VDR = new int[]{153,0,0};
        int verydarkred = 0;
        int[] VLB = new int[]{51,204,255};
        int verylightblue = 0;
        int[] LB = new int[]{51,153,255};
        int lightblue = 0;
        int[] Blue = new int[]{0,0,255};
        int blue = 0;
        int[] DB = new int[]{0,0,204};
        int darkblue = 0;
        int[] VDB = new int[]{0,0,153};
        int verydarkblue = 0;
        int[] VLG = new int[]{102,255,102};
        int verylightgreen = 0;
        int[] LG = new int[]{0,255,51};
        int lightgreen = 0;
        int[] Green = new int[]{0,204,0};
        int green = 0;
        int[] DG = new int[]{0,153,0};
        int darkgreen = 0;
        int[] VDG = new int[]{0,102,0};
        int verydarkgreen = 0;
        int[] White = new int[]{255,255,255};
        int white = 0;

        List<int[]> colorCodes = new ArrayList<int[]>();
        colorCodes.add(Black);
        colorCodes.add(VLR);
        colorCodes.add(LR);
        colorCodes.add(Red);
        colorCodes.add(DR);
        colorCodes.add(VDR);
        colorCodes.add(VLB);
        colorCodes.add(LB);
        colorCodes.add(Blue);
        colorCodes.add(DB);
        colorCodes.add(VDB);
        colorCodes.add(VLG);
        colorCodes.add(LG);
        colorCodes.add(Green);
        colorCodes.add(DG);
        colorCodes.add(VDG);
        colorCodes.add(White);

        int distance = 10000;
        for (int y = 0; y<xy[1]; y++)
        {
            for (int x = 0; x<xy[0]; x++)
            {
                int ind =0;
                int xDis = 0;
             Color clr = img.getColor(x,y);
             float r=0;
             float g=0;
             float b=0;
             r = 255*clr.getComponent(1);
             g = 255*clr.getComponent(2);
             b = 255*clr.getComponent(3);

             for (int c = 0; c < colorCodes.size(); c++)
             {
                 int[] check = colorCodes.get(c);
                 xDis += check[0]-r;
                 xDis += check[1]-g;
                 xDis += check[2]-b;
                 if (xDis < 0)
                 {
                     xDis = xDis * -1;
                 }
                if (xDis < distance)
                {
                    distance = xDis;
                    ind = c;
                }
             }
             switch (ind)
             {
                 case 1:
                        black++;
                     break;
                 case 2:
                     verylightred++;
                     break;
                 case 3:
                     lightred++;
                     break;
                 case 4:
                     red++;
                     break;
                 case 5:
                     darkred++;
                     break;
                 case 6:
                     verydarkred++;
                     break;
                 case 7:
                     verylightblue++;
                     break;
                 case 8:
                     lightblue++;
                     break;
                 case 9:
                     blue++;
                     break;
                 case 10:
                     darkblue++;
                     break;
                 case 11:
                     verydarkblue++;
                     break;
                 case 12:
                     verylightgreen++;
                     break;
                 case 13:
                     lightgreen++;
                     break;
                 case 14:
                     green++;
                     break;
                 case 15:
                     darkgreen++;
                     break;
                 case 16:
                     verydarkgreen++;
                     break;
                 case 17:
                     white++;
                     break;
             }
             ind = 0;
             xDis = 0;
             distance = 10000;
            }
        }
        ma.updateList(new String[]{"Black: "+black, "Very Light Red: "+verylightred,"Light Red: "+lightred,
        "Red: "+red, "Dark Red: " +darkred, "Very Dark Red: "+verydarkred, "Very Light Blue: "+verylightblue,
        "Light Blue: "+lightblue, "Blue: "+blue, "Dark Blue: "+darkblue, "Very Dark Blue: "+verydarkblue,
        "Very Light Green: "+verylightgreen, "Light Green: "+lightgreen, "Green: "+green,
        "Dark Green: "+darkgreen, "Very Dark Green: "+verydarkgreen, "White: "+white});
    }
}
