package com.example.pictureperfect;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.AndroidException;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    Manager manager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        manager = new Manager(this);
    }

    static final int REQUEST_IMAGE_CAPTURE = 1;
    public void pictureBtnClicked(View view)
    {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
        catch(ActivityNotFoundException e)
        {
            Log.d("ActivityNotFound", "pictureBtnClicked: "+e.getMessage());
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK)
        {
            Bundle extras = data.getExtras();
            Bitmap bmp = (Bitmap) extras.get("data");
            final ImageView imageView = (ImageView) findViewById(R.id.imageView);
            imageView.setImageBitmap(bmp);
            // start colorThread
            // ColorThread t = new ColorThread(bmp,this);
            // t.run();

            manager.startThread(bmp,0,(bmp.getWidth()/2)-1,0,(bmp.getHeight()/2)-1);
            manager.startThread(bmp,bmp.getWidth()/2,bmp.getWidth(),bmp.getHeight()/2,bmp.getHeight());
        }
    }

    public void updateList(String[] colors)
    {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, colors);
        ListView listView = (ListView)findViewById(R.id.top5Colors);
        listView.setAdapter(adapter);
    }
}