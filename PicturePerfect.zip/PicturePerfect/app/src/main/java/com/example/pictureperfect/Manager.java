package com.example.pictureperfect;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class Manager {
    MainActivity ma;
    List<Thread> threadList;
    List<ColorCode> colors;
    int threadId;
    boolean ran;

    public Manager(MainActivity ma) {
        this.ma = ma;
        threadList = new ArrayList<>();
        colors = getColorCodes();
        threadId = 0;
        ran = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    List<Thread> tList = new ArrayList<>(threadList);
                    if (tList.size() == 0 && ran == false) {
                        ran = true;
                        // only main thread can do this
                        ma.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                ma.updateList(countColors());
                            }
                        });
                    }
                    tList = null;
                }
            }
        });
        t.start();
    }

    private List<ColorCode> getColorCodes() {
        List<ColorCode> colors = new ArrayList<>();
        colors.add(new ColorCode(new int[]{0, 0, 0}, "Black"));
        colors.add(new ColorCode(new int[]{255, 102, 102}, "Very Light Red"));
        colors.add(new ColorCode(new int[]{255, 51, 51}, "Light Red"));
        colors.add(new ColorCode(new int[]{255, 0, 0}, "Red"));
        colors.add(new ColorCode(new int[]{204, 0, 0}, "Dark Red"));
        colors.add(new ColorCode(new int[]{153, 0, 0}, "Very Dark Red"));
        colors.add(new ColorCode(new int[]{51, 204, 255}, "Very Light Blue"));
        colors.add(new ColorCode(new int[]{51, 153, 255}, "Light Blue"));
        colors.add(new ColorCode(new int[]{0, 0, 255}, "Blue"));
        colors.add(new ColorCode(new int[]{0, 0, 204}, "Dark Blue"));
        colors.add(new ColorCode(new int[]{0, 0, 153}, "Very Dark Blue"));
        colors.add(new ColorCode(new int[]{102, 255, 102}, "Very Light Green"));
        colors.add(new ColorCode(new int[]{0, 255, 51}, "Light Green"));
        colors.add(new ColorCode(new int[]{0, 204, 0}, "Green"));
        colors.add(new ColorCode(new int[]{0, 153, 0}, "Dark Green"));
        colors.add(new ColorCode(new int[]{0, 102, 0}, "Very Dark Green"));
        colors.add(new ColorCode(new int[]{255, 255, 255}, "White"));
        return colors;
    }

    public void startThread(Bitmap bmp, int fromX, int toX, int fromY, int toY) {
        Thread t = new Thread(new ColorThreadMulti(bmp, fromX, toX, fromY, toY, getColorCodes(), this, threadId));
        t.setName(String.valueOf(threadId));
        threadId++;
        threadList.add(t);
        ran = false;
        t.run();
    }

    private String[] countColors() {
        String[] topFive = new String[5];
        List<ColorCode> orgCopy = new ArrayList<>(colors);

        for (int i = 0; i < 5; i++) {
            ColorCode temp = new ColorCode(new int[]{0, 0, 0}, "");
            int ind = 0;
            List<ColorCode> workinglist = new ArrayList<>(orgCopy);
            for (int y = 0; y < workinglist.size(); y++) {
                if (workinglist.get(y).count > temp.count) {
                    temp.cCode = workinglist.get(y).cCode;
                    temp.name = workinglist.get(y).name;
                    temp.count = workinglist.get(y).count;
                    ind = y;
                }
            }
            topFive[i] = temp.name + ": " + temp.count;
            orgCopy.remove(ind);
        }

        return topFive;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void threadCompletion(ColorThreadMulti ctm) {
        List<Thread> a = new ArrayList<>(threadList);
        for (Thread t : a) {
            // if thread is started by manager
            if (t.getName() == String.valueOf(ctm.id)) {
                // runs through colors
                for (ColorCode color : ctm.colors) {
                    // tries to add the color count
                    try {
                        colors.get(getColorIndexByName(color.name)).count += color.count;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                // remove thread from list
                threadList.remove(t);
            }
        }
        a = null;
    }

    private int getColorIndexByName(String name) {
        for (int i = 0; i < colors.size(); i++) {
            if (colors.get(i).name == name) {
                return i;
            }
        }
        return -1;
    }
}
