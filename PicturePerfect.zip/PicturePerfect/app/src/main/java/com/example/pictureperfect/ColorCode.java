package com.example.pictureperfect;

public class ColorCode {

    int[] cCode;
    String name;
    int count;

    public ColorCode(int[] cCode, String name)
    {
        this.cCode = cCode;
        this.name = name;
        count = 0;
    }
}
